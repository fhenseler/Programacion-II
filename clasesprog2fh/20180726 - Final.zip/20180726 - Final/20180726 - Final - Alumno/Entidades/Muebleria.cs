﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    // Primer Parcial:
    // Agrega un diccionario del tipo Asiento y cantidad <Asiento, int>
    // Sobrecargar el operador + para agregar asientos al diccionario de la Muebleria
    //  - Si el asiento es nuevo, agregarlo y colocar la cantidad en 1.
    //  - Si el asiento ya existe, aumentar la cantidad en 1.
    // Crear un constructor por defecto que instancie el diccionario.
    // Crear un indexador que retorne un elemento del diccionario. Si el índice indicado no existe, retornar null.
    // Crear un método que reciba un tipo de banqueta y si existe en el diccionario retorne un string informando el tipo y su cantidad.
    class Muebleria
    {

    }
}
